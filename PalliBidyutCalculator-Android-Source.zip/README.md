# পল্লী বিদ্যুৎ বিল ক্যালকুলেটর (Android)

## Features
- Bengali UI for residential prepaid electricity estimate
- Slab calculation using the exact rates provided by the user
- Optional demand charge, meter rent, and other charges
- Breakdown by each slab

## Rates used
- 1–75 units: ৳5.26
- 76–200 units: ৳8.50
- 201–300 units: ৳9.10
- 301–400 units: ৳9.62
- 401–600 units: ৳15.01
- Above 600 units: ৳17.35

## Build APK
1. Install Android Studio on a computer.
2. Open this folder as an existing Gradle project.
3. Let Gradle sync and install Android SDK 35 if prompted.
4. Select Build > Build APK(s).
5. APK output is typically at `app/build/outputs/apk/debug/app-debug.apk`.

The project source is provided; a compiled APK is not included.
The estimate uses the supplied rates and does not automatically determine official VAT/tariff rules.
