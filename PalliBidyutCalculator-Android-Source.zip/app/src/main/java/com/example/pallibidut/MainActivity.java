package com.example.pallibidut;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.text.InputType;
import android.widget.*;

import java.text.DecimalFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    private EditText unitsInput, demandInput, meterInput, otherInput;
    private LinearLayout breakdown;
    private TextView totalView, unitsView, noteView;
    private final DecimalFormat money = new DecimalFormat("#,##0.00");
    private final double[] limits = {75, 200, 300, 400, 600, Double.POSITIVE_INFINITY};
    private final double[] rates = {5.26, 8.50, 9.10, 9.62, 15.01, 17.35};
    private final String[] labels = {"১–৭৫ ইউনিট", "৭৬–২০০ ইউনিট", "২০১–৩০০ ইউনিট",
            "৩০১–৪০০ ইউনিট", "৪০১–৬০০ ইউনিট", "৬০০-এর বেশি"};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(7, 94, 67));
        getWindow().setNavigationBarColor(Color.rgb(7, 94, 67));
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(20), dp(20), dp(28));
        page.setBackgroundColor(Color.rgb(246, 249, 247));
        scroll.addView(page);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("পল্লী বিদ্যুৎ বিল ক্যালকুলেটর");
        title.setTextSize(24); title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(Color.rgb(7, 94, 67));
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("আবাসিক প্রিপেইড • স্ল্যাব অনুযায়ী হিসাব");
        subtitle.setTextSize(14); subtitle.setTextColor(Color.DKGRAY);
        LinearLayout.LayoutParams subp = params(-1, -2); subp.topMargin = dp(6);
        page.addView(subtitle, subp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(bg(Color.WHITE, 18, Color.rgb(226, 235, 229)));
        LinearLayout.LayoutParams cp = params(-1, -2); cp.topMargin = dp(20);
        page.addView(card, cp);

        addLabel(card, "মাসিক ব্যবহৃত ইউনিট");
        unitsInput = addInput(card, "যেমন: 200", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        addLabel(card, "ডিমান্ড চার্জ (৳) — জানা থাকলে");
        demandInput = addInput(card, "0", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        addLabel(card, "মিটার ভাড়া (৳) — জানা থাকলে");
        meterInput = addInput(card, "0", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        addLabel(card, "অন্যান্য চার্জ (৳) — জানা থাকলে");
        otherInput = addInput(card, "0", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        Button calc = new Button(this);
        calc.setText("বিল হিসাব করুন");
        calc.setTextColor(Color.WHITE);
        calc.setAllCaps(false);
        calc.setTextSize(16);
        calc.setBackground(bg(Color.rgb(8, 127, 91), 12, Color.rgb(8, 127, 91)));
        LinearLayout.LayoutParams bp = params(-1, dp(52)); bp.topMargin = dp(18);
        card.addView(calc, bp);

        LinearLayout resultCard = new LinearLayout(this);
        resultCard.setOrientation(LinearLayout.VERTICAL);
        resultCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        resultCard.setBackground(bg(Color.rgb(232, 247, 239), 18, Color.rgb(191, 226, 205)));
        LinearLayout.LayoutParams rp = params(-1, -2); rp.topMargin = dp(18);
        page.addView(resultCard, rp);

        TextView totalLabel = new TextView(this);
        totalLabel.setText("আনুমানিক মোট");
        totalLabel.setTextSize(15); totalLabel.setTextColor(Color.rgb(7, 94, 67));
        resultCard.addView(totalLabel);

        totalView = new TextView(this);
        totalView.setText("৳০.০০");
        totalView.setTextSize(30); totalView.setTypeface(null, Typeface.BOLD);
        totalView.setTextColor(Color.rgb(7, 94, 67));
        LinearLayout.LayoutParams tvp = params(-1, -2); tvp.topMargin = dp(4);
        resultCard.addView(totalView, tvp);

        unitsView = new TextView(this);
        unitsView.setText("ইউনিট লিখে হিসাব করুন");
        unitsView.setTextSize(14); unitsView.setTextColor(Color.DKGRAY);
        LinearLayout.LayoutParams uvp = params(-1, -2); uvp.topMargin = dp(4);
        resultCard.addView(unitsView, uvp);

        TextView breakdownTitle = new TextView(this);
        breakdownTitle.setText("স্ল্যাবভিত্তিক হিসাব");
        breakdownTitle.setTextSize(18); breakdownTitle.setTypeface(null, Typeface.BOLD);
        breakdownTitle.setTextColor(Color.rgb(33, 46, 40));
        LinearLayout.LayoutParams dtp = params(-1, -2); dtp.topMargin = dp(24);
        page.addView(breakdownTitle, dtp);

        breakdown = new LinearLayout(this);
        breakdown.setOrientation(LinearLayout.VERTICAL);
        breakdown.setPadding(dp(14), dp(8), dp(14), dp(8));
        breakdown.setBackground(bg(Color.WHITE, 14, Color.rgb(226, 235, 229)));
        LinearLayout.LayoutParams dbp = params(-1, -2); dbp.topMargin = dp(10);
        page.addView(breakdown, dbp);

        noteView = new TextView(this);
        noteView.setText("নোট: এটি আপনার দেওয়া ইউনিট রেট অনুযায়ী আনুমানিক হিসাব। ভ্যাট, ডিমান্ড চার্জ, মিটার ভাড়া ও অন্যান্য প্রযোজ্য চার্জ আলাদা হতে পারে।");
        noteView.setTextSize(12); noteView.setTextColor(Color.GRAY);
        LinearLayout.LayoutParams np = params(-1, -2); np.topMargin = dp(16);
        page.addView(noteView, np);

        calc.setOnClickListener(v -> calculate());
        Button reset = new Button(this);
        reset.setText("রিসেট");
        reset.setAllCaps(false);
        LinearLayout.LayoutParams resetp = params(-1, dp(48)); resetp.topMargin = dp(8);
        page.addView(reset, resetp);
        reset.setOnClickListener(v -> {
            unitsInput.setText(""); demandInput.setText("0"); meterInput.setText("0"); otherInput.setText("0");
            totalView.setText("৳০.০০"); unitsView.setText("ইউনিট লিখে হিসাব করুন");
            breakdown.removeAllViews();
        });
    }

    private void calculate() {
        String raw = unitsInput.getText().toString().trim();
        if (raw.isEmpty()) { unitsInput.setError("ইউনিট লিখুন"); unitsInput.requestFocus(); return; }
        double units, demand, meter, other;
        try {
            units = Double.parseDouble(raw);
            demand = parseOrZero(demandInput); meter = parseOrZero(meterInput); other = parseOrZero(otherInput);
        } catch (Exception e) { unitsInput.setError("সঠিক সংখ্যা লিখুন"); return; }
        if (units < 0 || demand < 0 || meter < 0 || other < 0) {
            unitsInput.setError("ঋণাত্মক সংখ্যা গ্রহণযোগ্য নয়"); return;
        }
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
                .hideSoftInputFromWindow(unitsInput.getWindowToken(), 0);

        breakdown.removeAllViews();
        double remaining = units, energy = 0;
        for (int i = 0; i < rates.length; i++) {
            double upper = limits[i];
            double lower = (i == 0) ? 0 : limits[i-1];
            double used = Math.max(0, Math.min(units, upper) - lower);
            if (Double.isInfinite(upper)) used = Math.max(0, units - lower);
            double cost = used * rates[i];
            energy += cost;
            addBreakdownRow(labels[i] + "  •  ৳" + String.format(Locale.US, "%.2f", rates[i]) + "/ইউনিট",
                    formatNumber(used) + " × ৳" + String.format(Locale.US, "%.2f", rates[i]),
                    "৳" + money.format(cost));
        }
        addDivider();
        addBreakdownRow("বিদ্যুৎ খরচ", "", "৳" + money.format(energy));
        addBreakdownRow("ডিমান্ড চার্জ", "", "৳" + money.format(demand));
        addBreakdownRow("মিটার ভাড়া", "", "৳" + money.format(meter));
        addBreakdownRow("অন্যান্য চার্জ", "", "৳" + money.format(other));
        double subtotal = energy + demand + meter + other;
        addBreakdownRow("মোট (ভ্যাটের আগে)", "", "৳" + money.format(subtotal));
        totalView.setText("৳" + money.format(subtotal));
        unitsView.setText(formatNumber(units) + " ইউনিট • বিদ্যুৎ খরচ ৳" + money.format(energy));
    }

    private double parseOrZero(EditText e) {
        String s = e.getText().toString().trim();
        if (s.isEmpty()) return 0;
        return Double.parseDouble(s);
    }
    private String formatNumber(double n) {
        if (n == Math.floor(n)) return String.format(Locale.US, "%.0f", n);
        return String.format(Locale.US, "%.2f", n);
    }
    private void addLabel(LinearLayout box, String text) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(14);
        t.setTextColor(Color.rgb(45, 59, 51));
        LinearLayout.LayoutParams p = params(-1, -2); p.topMargin = dp(12);
        box.addView(t, p);
    }
    private EditText addInput(LinearLayout box, String hint, int type) {
        EditText e = new EditText(this);
        e.setSingleLine(true); e.setTextSize(16); e.setInputType(type); e.setHint(hint);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        e.setBackground(bg(Color.rgb(249, 251, 250), 10, Color.rgb(211, 222, 215)));
        LinearLayout.LayoutParams p = params(-1, dp(48)); p.topMargin = dp(6);
        box.addView(e, p); return e;
    }
    private void addBreakdownRow(String title, String formula, String amount) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, dp(9), 0, dp(9));
        TextView a = new TextView(this); a.setText(title); a.setTextSize(14);
        a.setTextColor(Color.rgb(38, 51, 44)); a.setTypeface(null, Typeface.BOLD);
        row.addView(a);
        LinearLayout line = new LinearLayout(this); line.setGravity(Gravity.CENTER_VERTICAL);
        if (!formula.isEmpty()) {
            TextView f = new TextView(this); f.setText(formula); f.setTextSize(12);
            f.setTextColor(Color.GRAY); line.addView(f, new LinearLayout.LayoutParams(0, -2, 1));
        } else {
            View spacer = new View(this); line.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1));
        }
        TextView m = new TextView(this); m.setText(amount); m.setTextSize(14);
        m.setTypeface(null, Typeface.BOLD); m.setTextColor(Color.rgb(7, 94, 67));
        line.addView(m); row.addView(line); breakdown.addView(row);
    }
    private void addDivider() {
        View d = new View(this); d.setBackgroundColor(Color.rgb(224, 232, 226));
        LinearLayout.LayoutParams p = params(-1, dp(1)); p.topMargin = dp(3); p.bottomMargin = dp(3);
        breakdown.addView(d, p);
    }
    private GradientDrawable bg(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke); return d;
    }
    private LinearLayout.LayoutParams params(int w, int h) { return new LinearLayout.LayoutParams(w, h); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
